// ModLoader tahap 1: bukti injeksi + resolusi simbol + (opsional) uji hook di MCPE 0.15.10 ARM.
// Dimuat lewat meta-data android.app.lib_name = "modloader" (NativeActivity).
#include <android/log.h>
#include <dlfcn.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <unistd.h>

#define LOGFILE  "/sdcard/games/com.mojang/modloader.log"
#define HOOKFLAG "/sdcard/games/com.mojang/modloader_hook.txt"

static void L(const char* fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
    __android_log_print(ANDROID_LOG_INFO, "ModLoader", "%s", buf);
    FILE* f = fopen(LOGFILE, "a");
    if (f) { fprintf(f, "%s\n", buf); fclose(f); }
}

static void* g_mc = NULL;

// --- hook uji: OptionsScreen::init() (tipe return tidak diketahui, jadi diteruskan lewat uintptr_t) ---
typedef uintptr_t (*init_fn)(void*);
static init_fn orig_init = NULL;
static uintptr_t hook_init(void* self) {
    L("HOOK: OptionsScreen::init dipanggil self=%p", self);
    return orig_init ? orig_init(self) : 0;
}
typedef void (*MSHook_t)(void*, void*, void**);

static void try_hook() {
    if (access(HOOKFLAG, F_OK) != 0) { L("hook dilewati (file %s tidak ada)", HOOKFLAG); return; }
    void* ts = dlopen("libmcpelauncher_tinysubstrate.so", RTLD_NOW);
    if (!ts) { L("GAGAL dlopen tinysubstrate: %s", dlerror()); return; }
    MSHook_t hook = (MSHook_t)dlsym(ts, "MSHookFunction");
    void* target = g_mc ? dlsym(g_mc, "_ZN13OptionsScreen4initEv") : NULL;
    L("MSHookFunction=%p target=%p", (void*)hook, target);
    if (!hook || !target) { L("GAGAL: simbol tidak ketemu"); return; }
    L("memasang hook...");
    hook(target, (void*)hook_init, (void**)&orig_init);
    L("hook terpasang, orig=%p", (void*)orig_init);
}

__attribute__((constructor)) static void on_load() {
    L("=== modloader dimuat, pid=%d ===", (int)getpid());
    g_mc = dlopen("libminecraftpe.so", RTLD_NOW);
    L("libminecraftpe handle=%p %s", g_mc, g_mc ? "" : dlerror());
    if (g_mc) {
        const char* syms[] = {"ANativeActivity_onCreate", "JNI_OnLoad",
            "_ZN13OptionsScreen4initEv", "_ZN13OptionsScreen14_buttonClickedER6Button",
            "_ZN13OptionsScreen20createCategoryButtonsEv"};
        for (size_t i = 0; i < sizeof(syms)/sizeof(syms[0]); i++)
            L("  %s = %p", syms[i], dlsym(g_mc, syms[i]));
    }
    try_hook();
}

// NativeActivity memanggil ini di library "modloader"; teruskan ke milik Minecraft.
extern "C" __attribute__((visibility("default")))
void ANativeActivity_onCreate(void* activity, void* savedState, size_t savedStateSize) {
    typedef void (*fn_t)(void*, void*, size_t);
    if (!g_mc) g_mc = dlopen("libminecraftpe.so", RTLD_NOW);
    fn_t real = g_mc ? (fn_t)dlsym(g_mc, "ANativeActivity_onCreate") : NULL;
    L("ANativeActivity_onCreate -> real=%p", (void*)real);
    if (real) real(activity, savedState, savedStateSize);
}
