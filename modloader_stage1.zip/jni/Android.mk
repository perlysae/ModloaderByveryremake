LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := modloader
LOCAL_SRC_FILES := modloader.cpp
LOCAL_CPPFLAGS := -fno-exceptions -fno-rtti -O2
LOCAL_LDLIBS := -llog -ldl
include $(BUILD_SHARED_LIBRARY)
